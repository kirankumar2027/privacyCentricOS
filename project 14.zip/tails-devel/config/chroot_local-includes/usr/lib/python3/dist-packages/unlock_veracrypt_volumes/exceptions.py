class UdisksObjectNotFoundError(Exception):
    pass


class VolumeNotFoundError(Exception):
    pass


class AlreadyUnlockedError(Exception):
    pass