class SettingNotFoundError(Exception):
    pass
