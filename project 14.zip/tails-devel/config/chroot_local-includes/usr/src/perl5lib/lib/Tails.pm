=head1 NAME

Tails - Tails Perl library

=cut

package Tails;

use 5.10.1;
use strictures 2;
use autodie qw(:all);

use namespace::clean;

1;
