[[!meta title="Simplified HTML"]]

[[!pagetemplate template="nostyle.tmpl"]]

[[!inline pages="page(news/report_2*)" sort="-meta(date)" show="1" feeds="no"]]
