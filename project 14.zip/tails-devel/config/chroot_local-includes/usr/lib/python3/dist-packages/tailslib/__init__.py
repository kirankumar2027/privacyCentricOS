#!/usr/bin/python3
#
LIVE_USERNAME = "amnesia"
PERSISTENCE_SETUP_USERNAME = "tails-persistence-setup"
