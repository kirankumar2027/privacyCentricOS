// Prefs that *need* to be here because they are not honored
// if we set them via /usr/share/tails/tor-browser-prefs.js
user_pref("extensions.torbutton.launch_warning",  false);
user_pref("intl.accept_languages", "en-US, en");
user_pref("javascript.use_us_english_locale", true);
