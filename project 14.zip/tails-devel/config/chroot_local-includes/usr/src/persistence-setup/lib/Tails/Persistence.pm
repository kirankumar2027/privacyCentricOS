=head1 NAME

Tails::Persistence - main placeholder module

=cut

use 5.10.1;
use strictures 2;

1;
