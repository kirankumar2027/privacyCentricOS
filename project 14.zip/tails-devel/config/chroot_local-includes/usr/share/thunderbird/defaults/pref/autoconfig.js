pref("general.config.filename", "thunderbird.cfg");
pref("general.config.obscure_value", 0);